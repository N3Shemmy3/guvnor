<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/../include/config.php';

function respond($data, $code = 200)
{
    http_response_code($code);
    echo json_encode($data);
    exit;
}

function getJson()
{
    return json_decode(file_get_contents('php://input'), true) ?: [];
}

$method = $_SERVER['REQUEST_METHOD'];
$data = getJson();
$action = $_POST['action'] ?? $_GET['action'] ?? $data['action'] ?? '';

switch ($action) {
    case 'signup':
        require_once __DIR__ . '/auth/signup.php';
        signupUser($method);
        break;
    case 'signin':
        require_once __DIR__ . '/auth/signin.php';
        signinUser($method);
        break;
    default:
        respond(['success' => false, 'message' => 'Invalid action'], 400);
}
